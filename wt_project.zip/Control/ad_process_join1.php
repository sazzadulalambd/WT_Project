<?php

include "../Model/ad_model.php";

$eflag = 0;

if(isset($_POST["reset"])){
    session_unset();
    $fname='';
    $email='';
}

if(isset($_POST["ad_next1"]))
{

    $error = 0;

    $fname = $_POST["fname"];
    if(empty($fname)){
        echo "Enter Full name.<br>";
        $error = 1;
    }
    

    $email = $_POST["email"];
    if(empty($email) || !preg_match("/^([a-z0-9\+_\-]+)(\.[a-z0-9\+_\-]+)*@([a-z0-9\-]+\.)+[a-z]{2,6}$/ix",$email)){
        echo "Enter email<br>";
        $error = 1;
    }
    else{
        
        $mybd = new db();
        $conobj=$mybd->opencon();
        $mydata = $mybd->Checkmail("reg_admin",$conobj,$email);

        if($mydata->num_rows > 0)
        {
            echo "Email already exixts.<br>";
            $error = 1;
        }
        else {
            $error = 0;
        }
            
        }  

    //     $ext =  pathinfo($_FILES["myfile"]["name"],PATHINFO_EXTENSION);
    // $loc = pathinfo($_FILES["myfile"]["name"]);
    // if($ext == "jpg"){

    //     $_SESSION["img"] = $_FILES["myfile"];
    
        
    // }
    // else{
    //     echo "Only jpg file acceptable.";
    //     $error = 1;
    // }



    if($error == 0)
    {   
        $_SESSION["fname"] = $_POST["fname"];
        $_SESSION["email"] = $_POST["email"];
        header("location:s_admin_reg02.php");
    }
    else{
        $error = 0;
    }

   
    $mybd->closecon($conobj);
}
?>