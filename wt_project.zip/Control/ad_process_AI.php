<?php
include "../Model/ad_model.php"; 

    $mybd=new db();
    $conobj=$mybd->opencon();
    $mydata=$mybd->feterData("reg_admin",$conobj);
    if($mydata->num_rows > 0)
    {

echo "<table>";
echo"<tr><th>Full Name</th><th>Email</th><th>Phone Number</th><th>NID</th><th>Gender</th><th>Address</th>";
while($row=$mydata->fetch_assoc())
{
    echo"<tr>"; 
    echo"<th>".$row["Full_name"]."</th>";
    echo"<th>".$row["Email"]."</th>";
    echo"<th>0".$row["Phone_no"]."</th>";
    echo"<th>".$row["NID"]."</th>";
    echo"<th>".$row["Gender"]."</th>";
    echo"<th>".$row["Address"]."</th>";
    echo"</tr>";
}
echo"</table>";
}
else{
    echo"no result found";
}
$mybd->closecon($conobj);

?>