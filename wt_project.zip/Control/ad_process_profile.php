<?php
include "../Model/ad_model.php"; 

if(isset($_POST["Save"])){

    
        $mybd = new db();
        $conobj=$mybd->opencon();
        $mydata = $mybd->updateData("reg_admin",$conobj,$_SESSION["email"],$_POST["fname"],$_POST["phone"],$_POST["DOB"],$_POST["Address"],$_POST["Nname"],$_POST["pwd"],$_POST["Gender"],'');
        $mybd->closecon($conobj);

    $_SESSION["fname"] = $_POST["fname"];
    $_SESSION["email"];
    $_SESSION["Nname"] = $_POST["Nname"];
    $_SESSION["phone"] = $_POST["phone"];
    $_SESSION["Address"] = $_POST["Address"];
    $_SESSION["DOB"] = $_POST["DOB"];
    $_SESSION["gender"] = $_POST["Gender"];
    $_SESSION["pwd"] = $_POST["pwd"];
   
        
}
?>