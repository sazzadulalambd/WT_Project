<?php

session_start();
include "../Model/ad_model.php";    
$catagory = "";
if(isset($_POST["previous"])){
   header("location:s_admin_reg02.php");
}
if(isset($_POST["join"])){
    $password = $_POST["pwd"];
    if(empty($password)){
        echo("Enter your password.<br>");
    }
    else{
        if($password == $_POST["pwd2"])
        { if(!isset($_POST["checkbox1"])){
            echo "Check box must be selected.";
           }
            else{
            $_SESSION["pwd"] = $password;

        $mybd = new db();
        $conobj=$mybd->opencon();
        $mydata = $mybd->insertJoinData("reg_admin",$conobj,$_SESSION["email"],$_SESSION["fname"],$_SESSION["Skey"],$_SESSION["phone"],$_SESSION["DOB"],$_SESSION["Address"],$_SESSION["Nname"],$_SESSION["pwd"],$_SESSION["gender"],'');
        header("location:sign_in_admin.php");
        
        //session_destroy();
        $mydb->closecon($conobj);


            // $formdata = array( 
            //     'FullName'=> $_SESSION["fname"],
            //     'email'=> $_SESSION["email"],
            //     'password'=> $_SESSION["pwd"],
            //     'NIDName'=> $_SESSION["Nname"],
            //     'DOB' => $_SESSION["DOB"],
            //     'gender' => $_SESSION["gender"],
            //     'phone' => $_SESSION["phone"],
            //     'Address' => $_SESSION["Address"],
            //     'Securitykey' => $_SESSION["Skey"],

            //  );
            //  $existingdata = file_get_contents('../file/ad_join_info.json');
            //  $tempJSONdata = json_decode($existingdata);
            //  $tempJSONdata[] =$formdata;
           
            //  $jsondata = json_encode($tempJSONdata, JSON_PRETTY_PRINT);
         
         
            // if(file_put_contents("../file/ad_join_info.json", $jsondata)) {
            //     header("location:admin.php");
            
            // else {
            //   echo "Something went wrong";
                
            // }
        }
         
        }
        else{
            echo"Password did not match.<br>";
              } 
    }
}
?>