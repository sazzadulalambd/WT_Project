<?php 
  
         unset($_COOKIE['ad_autologin']); 
         setcookie('ad_autologin', null, -1, '/');
          session_start();
          if(session_destroy()){
            
              
              header("location:../view/home.php");
          }
        ?>