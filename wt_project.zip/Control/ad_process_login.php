<?php
session_start();
if(isset($_SESSION['email'])){
    header("location: admin.php");
    }
include "../Model/ad_model.php";
if(isset($_POST["submit"])){
    $flag=0;


    $email = $_POST["email"];
    $password = $_POST["pwd"];
    if(empty($email) || empty($password)){
        echo "Enter email or password <br>";
    }
    else{
        
        $mybd = new db();
        $conobj=$mybd->opencon();
        $mydata = $mybd->Checklogin("reg_admin",$conobj,$email,$password);

        if($mydata->num_rows > 0)
        {

            while($row=$mydata->fetch_assoc())
                {
                    

                 $_SESSION["fname"]=$row["Full_name"];
                 $_SESSION["email"]=$row["Email"];
                 $_SESSION["pwd"]=$row["Pass"];
                 $_SESSION["Nname"]=$row["NID"];
                 $_SESSION["DOB"]=$row["DOB"];
                 $_SESSION["gender"]=$row["Gender"];
                 $_SESSION["phone"]=$row["Phone_no"];
                 $_SESSION["Address"]=$row["Address"];
                 $_SESSION["Skey"]=$row["Security_key"];
                 
                 $flag=1;
                }
            
                header("location:admin.php");
        }
        else {
            echo "Incorrect email or password <br>";
        }
        //$mybd->closecon($conobj); 

        
        

        if(isset($_POST["checkbox"])){
            if($flag == 1){setcookie("ad_autologin",$_SESSION["email"],time()+3*24*60*60,"/");}


                            

            }
        }
            



}



?>

<!-- // if(isset($_COOKIE['ad_autologin']) && $_COOKIE['ad_autologin'] == '$_SESSION["email"]'){
                //     echo 'welcome back';
                // }else{
                //     //setcookie("ad_autologin",$_SESSION["email"],time()+2*24*60*60,"/","");
                //     echo 'Thanks for joining with us';
                // } -->

<!-- if(isset($_POST["submit"])){
    $data = file_get_contents("../file/ad_join_info.json");
        $readData = json_decode($data,true);
        foreach($readData as $myobject)
        {
            if($myobject["email"] == $_POST["email"]){
                if($myobject["password"] == $_POST["pwd"]){
                    $flag = 0;

                    $_SESSION["email"] = $_POST["email"];
                    $_SESSION["pwd"] = $_POST["pwd"];
                    $_SESSION["firstName"] = $myobject["FullName"];
                    $_SESSION["DOB"] = $myobject["DOB"];
                    $_SESSION["gender"] = $myobject["gender"];
                    $_SESSION["phone"] = $myobject["phone"];
                    $_SESSION["Address"] = $myobject["Address"];



                }
                else{
                    $flag = 1;
                }
            }
	           
        }
        
        
        if($flag == 1){
            echo "Incorrect email or password.<br>";
        }
        else if($flag == 0){
            if(isset($_POST["checkbox"])){
                //session_start();
                setcookie("ad_autologin",$_SESSION["email"],time()+2*24*60*60,"/","");
            header("location:admin.php");
        }
    
}
} -->
