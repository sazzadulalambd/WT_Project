<?php header("location:s_admin_reg01.php")?>

