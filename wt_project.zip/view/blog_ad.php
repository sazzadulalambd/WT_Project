<?php session_start();?>
<?php include "./nav_ber_ad_al.php"?>
<?php include "./welcome.php"?>

<iframe src="https://www.facebook.com/plugins/post.php?href=https%3A%2F%2Fwww.facebook.com%2FProgrammingwithSUAS%2Fposts%2F154527543631919&show_text=true&width=500" width="500" height="350"  scrolling="no" frameborder="0" allowfullscreen="true" allow="autoplay; clipboard-write; encrypted-media; picture-in-picture; web-share"></iframe>

    <iframe src="https://www.facebook.com/plugins/post.php?href=https%3A%2F%2Fwww.facebook.com%2FProgrammingwithSUAS%2Fposts%2F150719960679344&show_text=true&width=500" width="500" height="350"  scrolling="no" frameborder="0" allowfullscreen="true" allow="autoplay; clipboard-write; encrypted-media; picture-in-picture; web-share"></iframe>

        <iframe src="https://www.facebook.com/plugins/video.php?height=314&href=https%3A%2F%2Fwww.facebook.com%2FProgrammingwithSUAS%2Fvideos%2F207831298066314%2F&show_text=true&width=500&t=0" width="500" height="350"  scrolling="no" frameborder="0" allowfullscreen="true" allow="autoplay; clipboard-write; encrypted-media; picture-in-picture; web-share" allowFullScreen="true"></iframe>

            <iframe src="https://www.facebook.com/plugins/video.php?height=314&href=https%3A%2F%2Fwww.facebook.com%2FProgrammingwithSUAS%2Fvideos%2F330638091915871%2F&show_text=true&width=500&t=0" width="500" height="350" scrolling="no" frameborder="0" allowfullscreen="true" allow="autoplay; clipboard-write; encrypted-media; picture-in-picture; web-share" allowFullScreen="true"></iframe>

<?php include "./footer.php"?>