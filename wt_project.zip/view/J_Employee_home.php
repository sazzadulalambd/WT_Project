<html>
    <head>
</head>

<body>

<table>
    <h2>Employee Registration </h2>
    <From action="/action_page.php">
        
            <tr>
       <td>Home</td>
                  
    </tr>
       

 </table>
   
</form>
      </body>

    </html>
