<?php session_start();?>
<html>
<head>
<title>BePartner  </title> 
<head></head>
<body>
    <table>
        <tr>

          <th><a href="employee.php"><img src="../img/page_ icon.png" width="200" height="45"></a></th>
          <th> </th>
          <th><a href="employee.php"> Home </a></th>
          <th> </th>
          <th><a href="about.php"> About </a></th>
          <th> </th>
          <th><a href="blog.php"> Blog </a></th>
          <th> </th>
          <th><a href="contact.php"> Contact </a></th>
          <!-- <th> </th>
          <th><a href="home.php"> Become an Investor </a></th> -->
          <th> </th>
          <th><a href="s_admin_profile.php"> Profile</a></th>
          <th> </th>
          <th><a href="home.php">Logout</a></th>
          <th> </th>
         
          
    
          

        </tr>
        
       
        
    </table>

    <hr>
        <h1>Employee home</h1> 
</body>

</html>

<?php include "./footer.php"?>