<?php include "./nav_ber_in.php"?>
<?php include "./welcome.php"?>

<html>
    <body>
        <table>
            <tr>
                <td clospan ="4"> <h2> Admin memebers </h2>

                </td>

            </tr>
            <tr>
                <td>
                <img src="../img/SUAS.png" width="210" height="220">
                </td>
                <td>
                <img src="../img/MRH.png" width="210" height="220">
                </td>
                <td>
                <img src="../img/JF.jpg" width="210" height="220">
                </td>
                <td>
                <img src="../img/ALM.jpg" width="210" height="220">
                </td>

            </tr>

            <tr>
                <td class="center0">
                    <h3> <b>Sazzadul alam shawon</b></h3>
                </td>
                <td class="center0">
                    <h3> <b>Md. Rifat Hossain</b></h3>
                </td>
                <td class="center0" >
                    <h3> <b>Jannatul Ferdus</b></h3>
                </td>
                <td class="center0">
                    <h3> <b>Abdullah al Mahmud</b></h3>
                </td>

            </tr>

            <tr>
                <td class="center0">
                    <a href="https://www.facebook.com/sazzadulalamshawonbd/"><img src="../img/Facebook.png" width="25" height="25"></a>
<a href="mailto:sazzad.sua@gmail.com"><img src="../img/mail.png" width="25" height="25"></a>

                </td>
                <td class="center0">
                <a href="https://www.facebook.com/rrriiifffaaattt/"><img src="../img/Facebook.png" width="25" height="25"></a>
<a href="mailto:sazzad.sua@gmail.com"><img src="../img/mail.png" width="25" height="25"></a>
                </td>
                <td class="center0">
                <a href="https://www.facebook.com/yesmin.kakon.9/"><img src="../img/Facebook.png" width="25" height="25"></a>
<a href="mailto:jannatul6246ferdus@gmail.com"><img src="../img/mail.png" width="25" height="25"></a>
                </td>
                <td class="center0">
                <a href="https://www.facebook.com/abdullahal.mahmud.5015/"><img src="../img/Facebook.png" width="25" height="25"></a>
<a href="mailto:abdullahalmahmud06337@gmail.com"><img src="../img/mail.png" width="25" height="25"></a>
                </td>

            </tr>

</table>
<hr>

<h2> Location </h2>
<img src="../img/location.png" width=50% ></a><hr>

<h2> Contact </h2>
<p>
<b>Phone Number:</b>+8801772994093 <br>
<b>Address:</b> 20/A, Uttora, Dhaka 1230, Bangladesh. <br>
<b>Mail:</b>support@bepartner.com <br>
<b>Website:</b>www.bepartner.com</p>
</body> 
</html>


<?php include "./footer.php"?>







