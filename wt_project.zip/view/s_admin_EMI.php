<?php session_start();?>
<?php include "./nav_ber_ad_al.php"?>


<html>
<head>
  <!-- Stylesheets -->
  <link type="text/css" rel="stylesheet" href="../style/style.css" media="all">
<title>BePartner  </title> 
<head></head>
<body>
  

        <div class="row">
  <div class="column1">
    <center>
    <img src="../img/title_logo.png" width="88" height="80"> 
    <br>
    <p class ="nameBold"><?php echo $_SESSION["fname"] ?></p>

    <?php include "./s_admin_LM.php"?>
    
</center>
  </div> 
  <div class="column2">
    <h2>Employee Information</h2>
    <p>Some text..</p>
  </div>
</div>

</body>

</html>

<?php include "./footer.php"?>