<?php session_start();?>
<?php include "./nav_ber_ad_al.php"?>
<?php include "./welcome.php"?>

<html>
<head>
  <!-- Stylesheets -->
  <link type="text/css" rel="stylesheet" href="../style/style.css" media="all">
<title>BePartner  </title> 
</head>
    <body>


<a href="sign_in_admin.php"><h2>Admin</h2></a>

<p><b>Sazzadul alam shawon</b> <small>  19-39385-1</small></p>
<img src="../img/SUAS.png" width="110" height="120">
<a href="https://www.facebook.com/sazzadulalamshawonbd/"><img src="../img/Facebook.png" width="25" height="25"></a>
<a href="mailto:sazzad.sua@gmail.com"><img src="../img/mail.png" width="25" height="25"></a>


<p>
2020-2022 © BEPARTNER <br>
POWERED BY CODE HUNTER SOFTWARE DEVELOPMENT TEAM.<br>
AMERICAN INTERNATIONAL UNIVERSITY-BANGLADESH</p>

<p><b>Md. Rifat Hossain</b> <small>  18-38939-3</small></p>
<img src="../img/MRH.png" width="110" height="120">
<a href="https://www.facebook.com/rrriiifffaaattt/"><img src="../img/Facebook.png" width="25" height="25"></a>
<a href="mailto:sazzad.sua@gmail.com"><img src="../img/mail.png" width="25" height="25"></a>
<p>
2020-2022 © BEPARTNER <br>
POWERED BY CODE HUNTER SOFTWARE DEVELOPMENT TEAM.<br>
AMERICAN INTERNATIONAL UNIVERSITY-BANGLADESH</p>


<p><b>Jannatul Ferdus</b> <small>  19-39371-1</small></p>
<img src="../img/JF.jpg" width="110" height="120">
<a href="https://www.facebook.com/yesmin.kakon.9/"><img src="../img/Facebook.png" width="25" height="25"></a>
<a href="mailto:jannatul6246ferdus@gmail.com"><img src="../img/mail.png" width="25" height="25"></a>
<p>
2020-2022 © BEPARTNER <br>
POWERED BY CODE HUNTER SOFTWARE DEVELOPMENT TEAM.<br>
AMERICAN INTERNATIONAL UNIVERSITY-BANGLADESH </p>


<p><b>Abdullah al Mahmud</b> <small>  19-39500-1</small></p>
<img src="../img/ALM.jpg" width="110" height="120">
<a href="https://www.facebook.com/abdullahal.mahmud.5015/"><img src="../img/Facebook.png" width="25" height="25"></a>
<a href="mailto:abdullahalmahmud06337@gmail.com"><img src="../img/mail.png" width="25" height="25"></a>
<p>
2020-2022 © BEPARTNER <br>
POWERED BY CODE HUNTER SOFTWARE DEVELOPMENT TEAM.<br>
AMERICAN INTERNATIONAL UNIVERSITY-BANGLADESH </p>

<hr>

<a href="sign_in_employee.php"><h2>Employee</h2></a>

<p><b>Sazzad Hamid</b> <small>  Chief Operating Officer (COO)</small></p>
<p>
In the hierarchal set up the Chief Operating Officer holds the second place. In some entities, COO is also called the Chief Operations Director or Chief Operations Officer.  COO acts as focal point to execute business plans. Such person assists the company to work effectively and ensures its financial strength. COO is a leader as well as a supervisor of the company, who confirms that employees are executing the plans of the CEO.</p>

<p><b>Rifat Hossain</b> <small>  Chief Technology Officer (CTO)</small></p>
<p>
n the designations in a private company, next comes the Chief Technology Officer. A Chief Technology Officer is a senior executive in the technology department of the company. Such person is responsible for managing and supervising maintenance of technology and development aspects.

Moreover, the CTO should oversee the technological process, policies, asset maintenance of the company.</p>


<p><b>Dola Shaha</b> <small>  Chief Financial Officer (CFO)</small></p>
<p>
In a corporate setup, a Chief Financial Officer or the CFO does financial planning, monitors the cash flow and does other financial activities. Such person is similar to the controller or treasurer of a company. He checks the accuracy of the financial statements and company’s reports.

CFO also conducts SWOT analysis of the company regularly. SWOT means Strength, Weakness, Opportunities and Threat. Further, the standard duties of a CFO are planning, bookkeeping, accounting, fundraising, budgeting and such other financial/accounting matters. </p>


<p><b>Abdullah al Hafij</b> <small>  Chief Marketing Officer (CMO)</small></p>
<p>
A Chief Marketing Officer is a marketing executive engaged in tasks such as managing marketing campaigns, enhancing brand image etc. Further, the Chief Marketing Officer directly operates with marketing and sales department to execute marketing strategies and policies.

All the managers are required to report to these officers within a private company. </p>


<p><b>Jahangir Alam</b> <small>  Chief Legal Officer (CLO)</small></p>
<p>
A Chief Legal Officer acts as a senior legal executive who assists in reducing the legal risks in a company. The main function of a CLO is to advise on regulatory as well as on legal concerns to stakeholders/employees of the company. He reduces the litigation risks.

 The CLO also handles legal matters of a company and acts as a first person for communication with the authorities. There may be more than one manager functioning under the legal departments headed by the CLO. </p>


<?php include "./footer.php"?>


</body>

</html>