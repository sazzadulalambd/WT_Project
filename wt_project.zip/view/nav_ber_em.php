<!--shawon,sazzadul alam [19-39385-1]-->
<head>
<title>BePartner  </title> 
</head>
    <table>
        <tr>

          <th><a href="home.php"><img src="../img/page_ icon.png" width="200" height="45"></a></th>
          <th> </th>
          <th><a href="home.php"> Home </a></th>
          <th> </th>
          <th><a href="about.php"> About </a></th>
          <th> </th>
          <th><a href="blog.php"> Blog </a></th>
          <th> </th>
          <th><a href="contact.php"> Contact </a></th>
          <!-- <th> </th>
          <th><a href="home.php"> Become a Investor </a></th> -->
          <th> </th>
          <th><a href="sign_in_employee.php"> Sign In </a></th>
          <th> </th>
          <th><a href="join_employee.php"> Join </a></th>
          <th> </th>
    
        </tr>
       
    </table>
    <hr>
