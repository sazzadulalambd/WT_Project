<hr>
<center><p> Home | About | Blog | Contact |               © www.bepartner.com   </p></center>