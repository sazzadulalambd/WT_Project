<!--shawon,sazzadul alam [19-39385-1]-->

<head>
  <!-- Stylesheets -->
  <link type="text/css" rel="stylesheet" href="../style/style.css" media="all">
<title>BePartner  </title> 
</head>
<div class="navblock">

    <table>
        <tr>

          <td><a href="admin.php"><img src="../img/page_ icon.png" width="200" height="45"></a></td>
          <td> </td>
          <td><a href="admin.php"><button class ="buttonNav"> Home </button></a></td>
          <td> </td>
          <td><a href="about_ad.php"><button class ="buttonNav"> About</button> </a></td>
          <td> </td>
          <td><a href="blog_ad.php"><button class ="buttonNav"> Blog </button></a></td>
          <td> </td>
          <td><a href="contact_ad.php"><button class ="buttonNav"> Contact </button></a></td>
          <td> </td>
          <!-- <th><a href="home.php"> Become a Investor </a></th>
          <th> </th> -->
          <!-- <th><a href="sign_in_admin.php"> Sign In </a></th>
          <th> </th> -->
          <!-- <th><a href="join_admin.php"> Join </a></th>
          <th> </th> -->

          <td><a href="s_admin_profile.php"><button class ="buttonNav"> <?php echo $_SESSION["fname"] ?> </button></a></td>
          <td> </td>
          <td><a href="../Control/ad_logout.php"><button class ="buttonNav"> Logout </button></a></td>
          <td> </td>
    
        </tr>
       
    </table>
</div>

    <hr>
