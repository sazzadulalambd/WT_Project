<?php include "./in_nav_bar_my_business.php"?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>My Business | BePartner</title>
</head>
<body>
    <hr>
    <table>
        <tr>
            <td><h3>Brixel</h3><h2>Create With Heart</h2><h1>Build With Mind</h1>
            Keep the whole family comfortable with building construction. We <br> provide 24/7 emergency water extraction service in Dhaka city.<br>
            <h4>Investment: 1 crore.</h4>
            <h4>Share: 5% of the company.</h4>
            <input type="button" value="Arrange meeting">
            <input type="button" value="Contact CEO">
            </td>

            <td>
            <img src="../img/bar.png" alt="hello"       width="10"
            height="600" align = "right">
            </td>
            <td><img src="../img/building.jpeg" alt="hello"       width="1040"
            height="600" align = "right"></td>
        </tr>
    </table>
      <hr>
      <hr>
    </body>
    </html>