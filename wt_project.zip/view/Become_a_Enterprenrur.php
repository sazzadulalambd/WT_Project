<?php include "./nav_ber_en.php"?>
<?php include "./welcome.php"?>
<img src="../img/img_02_.jpg" width=100% >

<?php include "./footer.php"?>