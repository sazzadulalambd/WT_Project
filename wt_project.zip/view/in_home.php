<?php include "in_nav_bar_home.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Home | BePartner</title>
</head>
<body>
<form action="" method="post">
    <hr>
    <table>
        <tr>
            <td><h1>Find the best intreprenures<br> to invest</h1>
            <h3>Search Collaborate Invest Earn</h3><br><br><br><br><br>
            <input type="text" name="search"  placeholder="Search here">
            <input type="submit" name="search_button" value="Search">
            <br>Propular: 
            <a href="" >Agriculture</a>
            <a href="">Garments</a>
            <a href="">Science and technology</a>
            <a href="">Utilities</a></td>
            <!-- <td><img src="../img/img_01_.png" alt="hello" width="300"
            height="500" align = "right"></td> -->
            <td><img src="../img/in_img_01_.jpg" alt="hello" width="1000"
            height="600" align = "left"></td>
        </tr>
    </table>
    <hr>
    <table>
        <tr>
            <th>News & Events</th>
        </tr>
    </table>
</body>
</html>
<?php include "../control/in_process_home.php"?>