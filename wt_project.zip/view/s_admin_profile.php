<?php session_start();?>
<?php include "./nav_ber_ad_al.php"?>


<html>
<head>
  <!-- Stylesheets -->
  <link type="text/css" rel="stylesheet" href="../style/style.css" media="all">
<title>BePartner  </title> 
<head></head>
<body>
  

        <div class="row">
  <div class="column1">
    <center>
    <img src="../img/title_logo.png" width="88" height="80"> 
    <br>
    <p class ="nameBold"><?php echo $_SESSION["fname"] ?></p>

    <?php include "./s_admin_LM.php"?>
    
</center>
  </div> 
  <div class="column2">
    <h2>Account Information</h2>

    <center>
<form action="" method="post">

<table>
<tr>
<td>Full name:</td>
<td><input type="text" name="fname" value="<?php if(isset($_SESSION["fname"]))echo $_SESSION["fname"]?>"></td>
</tr>

<tr>
<td>Email:</td>
  <td><input type="text" name="email" disabled value="<?php if(isset($_SESSION["email"]))echo $_SESSION["email"]?>"></td>
</tr>



<tr>
<td>NID number:</td>
<td><input type="text" name="Nname" value="<?php if(isset($_SESSION["Nname"]))echo $_SESSION["Nname"]?>"></td>
</tr>

<tr>
<td>Phone Number:</td>
<td><input type="text" name="phone" value="<?php if(isset($_SESSION["phone"]))echo $_SESSION["phone"]?>"></td>
</tr>
<tr>
<td>Date of birth:</td>
<td><input type="date" name="DOB" value="<?php if(isset($_SESSION["DOB"]))echo $_SESSION["DOB"]?>"></td>
</tr>

<tr>
<td>Address:</td>
<td><input type="text" name="Address" value="<?php if(isset($_SESSION["Address"]))echo $_SESSION["Address"]?>"></td>
</tr>
<tr>
<tr>
    <td>Gender:</td>
    <td><?php if(isset($_SESSION["gender"]))echo $_SESSION["gender"]?>
      <select id="designation" name="Gender">
  <option value="Male">Male</option>
  <option value="Female">Female</option>
  <option value="Other">Other</option>
</select> 
</td>
    </tr>

<tr>
<td>Security key:</td>
<td><input type="text" name="Skey" disabled value="<?php if(isset($_SESSION["Skey"]))echo $_SESSION["Skey"]?>"></td>
</tr>

<tr>
<td>Password:</td>
<td><input type="text" name="pwd" value="<?php if(isset($_SESSION["pwd"]))echo $_SESSION["pwd"]?>"></td>
</tr>

<td>Profile picture:</td>
<td><input type="file" name="myfile"></td>
</tr>
<tr> 
<td><input type="submit" value="Save" name="Save">
<input type="reset" name="Reset"></td>
</tr>
</table>
<?php include "../control/ad_process_profile.php"?>
</form>
</center>
  </div>
</div>

</body>

</html>

<?php include "./footer.php"?>