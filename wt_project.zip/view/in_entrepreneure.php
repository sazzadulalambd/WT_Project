<?php include "in_nav_bar_entrepreneure.php"?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Entrepreneure | BePartner</title>
</head>
<body>
    <hr>
    <table>
        <tr>
            <td><h3>Brixel</h3><h2>Create With Heart</h2><h1>Build With Mind</h1>
            Keep the whole family comfortable with building construction. We <br> provide 24/7 emergency water extraction service in Dhaka city.<br>
            <h4>Asking: 1 crore for 5% of the company.</h4>
            <input type="button" value="Give Offer">
            <input type="button" value="Contact CEO">
            </td>

            <td>
            <img src="../img/bar.png" alt="hello"       width="10"
            height="600" align = "right">
            </td>
            <td><img src="../img/building.jpeg" alt="hello"       width="1040"
            height="600" align = "right"></td>
        </tr>
    </table>
    <hr>
    <table>
        <br><br>
        <tr>
            <td><img src="../img/img_01_.png" alt="hello"       width="100"
            height="100" align = "right">
            </td>
            <td>
                <h3>Let's Build <br> Your Dream Together</h3>
            </td>
            <td>
            <img src="../img/bar.png" alt="hello"       width="10"
            height="70" align = "right">
            </td>
            <td>
                Consecteture adipising elit. sed do eiusmod te,por incididunt ut labore et dolore magna <br> aliqua. ut enim ad minim veniam. Lorem ipsum dolor sit amet. consectetur adipisicing elit.<br> sed do eiusmod tempor incididunt.
            
            </td>
            <td><img src="../img/img_01_.png" alt="hello"       width="100"
            height="100" align = "right">
            </td>
            <td>
            <img src="../img/bar.png" alt="hello"       width="10"
            height="70" align = "right">
            </td>
            <td>
                <b>Tota profit:</b> 4.7 crore.<br>
                <b>Last Month profit:</b> 10 laks.<br>
                <b>Last year profit:</b> 90 laks.<br>
                <b>Validation:</b> 50 crore.
            </td>
        </tr>
    </table>
    <table>
    <tr><br><br>
            <td><img src="../img/img_01_.png" alt="hello"       width="100"
            height="100" align = "right">
            </td>
            <td>
                <b>Build Renovation</b><br>
                consectetur adipidicing elit. sed<br>
                do eiusmed tempor incididunt <br>
                ut labore et dilire magna<br>
                aliqua. Ut enim ad minim veniam.
            </td>
            <td><img src="../img/img_01_.png" alt="hello"       width="100"
            height="100" align = "right">
            </td>
            <td>
                <b>Building Construction</b><br>
                consectetur adipidicing elit. sed<br>
                do eiusmed tempor incididunt <br>
                ut labore et dilire magna<br>
                aliqua. Ut enim ad minim veniam.
            </td>
            </td>
            <td><img src="../img/img_01_.png" alt="hello"       width="100"
            height="100" align = "right">
            </td>
            <td>
                <b>Architecture Design</b><br>
                consectetur adipidicing elit. sed<br>
                do eiusmed tempor incididunt <br>
                ut labore et dilire magna<br>
                aliqua. Ut enim ad minim veniam.
            </td>
            <td><img src="../img/img_01_.png" alt="hello"       width="100"
            height="100" align = "right">
            </td>
            <td>
                <b>Building Maintenance</b><br>
                consectetur adipidicing elit. sed<br>
                do eiusmed tempor incididunt <br>
                ut labore et dilire magna<br>
                aliqua. Ut enim ad minim veniam.
            </td>
        </tr>
    </table>
</body>
</html>