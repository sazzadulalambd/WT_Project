
    <a href="./s_admin_profile.php">
<button class ="buttonAD" name="AF">Account Information</button><br></a>

<a href="./s_admin_AI.php">
<button class ="buttonAD" name="AI">Admin Information</button><br></a>

<a href="./s_admin_EMI.php">
<button class ="buttonAD" name="EMI">Employee Information</button><br></a>

<a href="./s_admin_II.php">
<button class ="buttonAD" name="II">Investor Information</button><br></a>

<a href="./s_admin_ENI.php">
<button class ="buttonAD" name="ENI">Enterprenrur Information</button><br></a>

<a href="./s_admin_NF.php">
<button class ="buttonAD" name="NF">Notifications</button><br></a>
