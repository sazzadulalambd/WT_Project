

<html>                                                                                   
<body>
<?php include "../control/process_home.php"?>
<?php include "nav_ber_in.php"?>
<?php include "welcome.php"?>

<img src="../img/img_01_.jpg" width=100%  >



<?php include "footer.php"?>
</body>

</html>

