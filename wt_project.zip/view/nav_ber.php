<!--shawon,sazzadul alam [19-39385-1]-->
<head>
<link type="text/css" rel="stylesheet" href="../style/style.css" media="all">
<head>
    <table>
        <tr>

          <td><a href="home.php"><img src="../img/page_ icon.png" widtd="200" height="45"></a></td>
          <td> </td>
          <td><a href="home.php"><button class ="buttonNav"> Home </button></a></td>
          <td> </td>
          <td><a href="about.php"><button class ="buttonNav"> About </button></a></td>
          <td> </td>
          <td><a href="blog.php"><button class ="buttonNav"> Blog </button></a></td>
          <td> </td>
          <td><a href="contact.php"><button class ="buttonNav"> Contact </button></a></td>
          <td> </td>
          <td><a href="Become_a_Enterprenrur.php"><button class ="buttonNav"> Become a Enterprenrur </button></a></td>
          <td> </td>
          <td><a href="sign_in_investor.php"><button class ="buttonNav"> Sign In </button></a></td>
          <td> </td>
          <td><a href="join_investor.php"><button class ="buttonNav"> Join </a></button></td>
          <td> </td>
    
        </tr>
       
    </table>
    <hr>
