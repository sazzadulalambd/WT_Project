<?php

class db{

    function opencon(){
    
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "wt_project";

        $conn = new mysqli($servername,$username,$password,$dbname);

        if($conn->connect_error){
             echo "could not connect";
        }
        else{
            return $conn;
        }

    }

    function insertJoinData($tname,$conn,$Email,$Full_name,$Security_key,$Phone_no,$DOB,$Address,$NID,$Pass,$Gender,$Img){

        $sql = "INSERT INTO $tname (Email,Full_name,Security_key,Phone_no,DOB,Address,NID,Pass,Gender,Img) VALUES('$Email','$Full_name','$Security_key','$Phone_no','$DOB','$Address','$NID','$Pass','$Gender','$Img')";
        
        if($conn->query($sql)===TRUE){
            //echo "Data inserted";
            return TRUE;
        }
        else{
            echo "data cant be inserted".$conn->error;
            return FALSE;
        }

    }
    function updateData($tname,$conn,$Email,$Full_name,$Phone_no,$DOB,$Address,$NID,$Pass,$Gender,$Img){

        $sql = "UPDATE $tname SET Email='$Email',Full_name='$Full_name',Phone_no='$Phone_no',DOB='$DOB',Address='$Address',NID='$NID',Pass='$Pass',Gender='$Gender',Img='$Img' WHERE Email = '$Email'";
        
        if($conn->query($sql)===TRUE){
            echo "Data updated succefully";
            return TRUE;
        }
        else{
            echo "data don't update".$conn->error;
            return FALSE;
        }

    }

    function Checklogin($table,$conn,$Email,$Pass)
 {
$result = $conn->query("SELECT * FROM  $table WHERE Email='". $Email."' AND Pass='". $Pass."'");
 return $result;
 }

    function Checkmail($tname,$conn,$Email){
        $result = $conn->query("SELECT * FROM  $tname WHERE Email='".$Email."'");
        return $result;
    }

    function Checkphonenumber($tname,$conn,$Phone_no){
        $result = $conn->query("SELECT * FROM  $tname WHERE Phone_no='".$Phone_no."'");


        return $result;
        
    }

    function Checknid($tname,$conn,$NID){
        $result = $conn->query("SELECT * FROM  $tname WHERE NID='".$NID."'");
        return $result;
    }
    function CheckSKey($tname,$conn,$security_key){
        $result = $conn->query("SELECT * FROM  $tname WHERE security_key='".$security_key."'");
    
        return $result;
    }

    function feterData($tablename,$conn){
        $sql = "SELECT * FROM $tablename";
    
        $result = $conn->query($sql);
        return $result;
    }
    


    function closecon($conn){
        return $conn->close();
    }

}
?>