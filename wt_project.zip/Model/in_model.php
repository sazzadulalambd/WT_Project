<?php

class db{

    function opencon(){
    
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "wt_project";

        $conn = new mysqli($servername,$username,$password,$dbname);

        if($conn->connect_error){
            echo "could not connect";
        }
        else{
            return $conn;
        }

    }

    function insertJoinData($tname,$email,$pass,$firstName,$lastName,$DOB,$gender,$phone,$pAddress,$oname,$linumber,$tin,$oaddress,$edate,$oemail,$site,$img,$cover,$conn){

        $sql = "INSERT INTO $tname (email,pass,firstname,lastname,DOB,gender,phone,paddress,oname,linumber,tin,oaddress,edate,oemail,site,img,cover) VALUES('$email','$pass','$firstName','$lastName','$DOB','$gender','$phone','$pAddress','$oname','$linumber','$tin','$oaddress','$edate','$oemail','$site','$img','')";
        
        if($conn->query($sql)===TRUE){
            echo "Data inserted";
            return TRUE;
        }
        else{
            echo "data cant be inserted".$conn->error;
            return FALSE;
        }

    }

  
    


    function closecon($conn){
        return $conn->close();
    }

}
?>